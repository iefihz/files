此工程为文档 [docker部署常用软件.md#6.3-单服务 · iefihz/notes - Gitee.com](https://gitee.com/iefihz/notes/blob/master/docker/docker部署常用软件.md#63-单服务) 中的源码

