package com.iefihz.single.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * IndexController
 *
 * @author He Zhifei
 * @date 2022/4/12 14:48
 */
@RestController
@RequestMapping("/index")
public class IndexController {

    private static final Logger logger = LoggerFactory.getLogger(IndexController.class);

    @Value("${server.port}")
    private Integer port;

    @RequestMapping
    public String index() {
        String msg = "====== 服务器信息 --> " + getIp(null) + ":" + port + " ======";
        logger.info(msg);
        return msg;
    }

    /**
     * 获取请求ip
     *
     * @param request 请求
     * @return 请求ip
     */
    public static String getIp(HttpServletRequest request) {
        if (request == null) {
            request = getRequest();
        }
        if (request == null) {
            return "unknown";
        }
        String ip = request.getHeader("x-forwarded-for");
        if (ipIsBlankOrUnknown(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ipIsBlankOrUnknown(ip)) {
            ip = request.getHeader("X-Forwarded-For");
        }
        if (ipIsBlankOrUnknown(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ipIsBlankOrUnknown(ip)) {
            ip = request.getHeader("X-Real-IP");
        }
        if (ipIsBlankOrUnknown(ip)) {
            ip = request.getRemoteAddr();
        }
        return "0:0:0:0:0:0:0:1".equals(ip) ? "127.0.0.1" : ip;
    }

    /**
     * 获取HttpServletRequest
     *
     * @return HttpServletRequest
     */
    public static HttpServletRequest getRequest() {
        return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
    }

    /**
     * 判断ip是否为空或者"unknown"
     * @param ip
     * @return
     */
    private static boolean ipIsBlankOrUnknown(String ip) {
        return ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip);
    }
}
