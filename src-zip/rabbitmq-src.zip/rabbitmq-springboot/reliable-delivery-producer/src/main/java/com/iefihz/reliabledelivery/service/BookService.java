package com.iefihz.reliabledelivery.service;

import com.iefihz.reliabledelivery.entity.Book;

public interface BookService {
    Book add(Book book);
}
