package com.iefihz.rabbitmq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitmqSpringbootTestApplicationTests {

    @Test
    void contextLoads() {
    }

}
